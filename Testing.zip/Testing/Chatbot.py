# -*- coding: utf-8 -*-
from chatterbot import ChatBot

# Create a new chat bot named Charlie
chatbot = ChatBot(
    'Charlie',
	logic_adapters=[
        {
            'import_path': 'LogicAdapter.meeting.MeetingLogicAdapter'
        },
        "chatterbot.logic.BestMatch"
    ],
    trainer='chatterbot.trainers.ListTrainer'
)

chatbot.train([
    'How are you?',
    'I am good.',
    'That is good to hear.',
    'Thank you',
    'You are welcome.',
])

user_request = ''
# Get a response to the input text 'How are you?'
#a = input("Question")
print ("Hey, My name is robo kumar! How may i help u?")
while user_request.lower() != "exit":
    user_request = input()
    response = chatbot.get_response(user_request)
    print(response)

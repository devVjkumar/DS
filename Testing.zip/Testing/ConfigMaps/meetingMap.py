def class meetingMap:
    def __init__(self):
        self.meetingLocationMap = {}
    def loadLocations(self):
        self.meetingLocationMap["Tidel"] = "It is located in coimbatore."
    def lookUpLocation(self,location):
        locationValue = meetingLocationMap.get(location)
        if locationValue != None:
            return True,locationValue
        else:
            return False,"No Location found."
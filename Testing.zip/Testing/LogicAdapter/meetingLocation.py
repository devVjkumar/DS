from chatterbot.logic import LogicAdapter
from chatterbot.comparisons import levenshtein_distance
import copy

class MeetingLogicAdapter(LogicAdapter):
    def __init__(self, **kwargs):
        super(MeetingLogicAdapter, self).__init__(**kwargs)

    def can_process(self, statement):
        request = statement;
        meetingRequest = copy.deepcopy(request)
        meetingRequest.text = "Book a meeting room with location" 
        print (meetingRequest,statement)
        print (levenshtein_distance.compare(meetingRequest,statement))
        if (levenshtein_distance.compare(meetingRequest,statement)>0.5):
            return True
        else:
            return False

    def process(self, statement):
        import random
        confidence = 1
        print ("Inside KumarLol Logic adapter")
        # For this example, we will just return the input as output
        selected_statement = statement
        selected_statement.confidence = confidence
        selected_statement.text = 'Kumar_lol'
        return confidence, selected_statement